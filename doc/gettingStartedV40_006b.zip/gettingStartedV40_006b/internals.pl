# LaTeX2HTML 2002-2-1 (1.71)
# Associate internals original text with physical files.


$key = q/sg6/;
$ref_files{$key} = "$dir".q|node22.html|; 
$noresave{$key} = "$nosave";

$key = q/waveformsComp/;
$ref_files{$key} = "$dir".q|node9.html|; 
$noresave{$key} = "$nosave";

$key = q/sg05/;
$ref_files{$key} = "$dir".q|node20.html|; 
$noresave{$key} = "$nosave";

$key = q/wv8000/;
$ref_files{$key} = "$dir".q|node23.html|; 
$noresave{$key} = "$nosave";

$key = q/sourceinfo/;
$ref_files{$key} = "$dir".q|node15.html|; 
$noresave{$key} = "$nosave";

$key = q/APindexExtraction/;
$ref_files{$key} = "$dir".q|node31.html|; 
$noresave{$key} = "$nosave";

$key = q/wv700/;
$ref_files{$key} = "$dir".q|node24.html|; 
$noresave{$key} = "$nosave";

$key = q/howtoUseNewF0/;
$ref_files{$key} = "$dir".q|node8.html|; 
$noresave{$key} = "$nosave";

$key = q/wv0/;
$ref_files{$key} = "$dir".q|node19.html|; 
$noresave{$key} = "$nosave";

$key = q/wv2/;
$ref_files{$key} = "$dir".q|node21.html|; 
$noresave{$key} = "$nosave";

$key = q/sg2/;
$ref_files{$key} = "$dir".q|node21.html|; 
$noresave{$key} = "$nosave";

$key = q/apforaiueo/;
$ref_files{$key} = "$dir".q|node31.html|; 
$noresave{$key} = "$nosave";

$key = q/wv05/;
$ref_files{$key} = "$dir".q|node20.html|; 
$noresave{$key} = "$nosave";

$key = q/sg7/;
$ref_files{$key} = "$dir".q|node25.html|; 
$noresave{$key} = "$nosave";

$key = q/aoeriodicityEstimation/;
$ref_files{$key} = "$dir".q|node31.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_kawahara2006ast/;
$ref_files{$key} = "$dir".q|node28.html|; 
$noresave{$key} = "$nosave";

$key = q/sg8000/;
$ref_files{$key} = "$dir".q|node23.html|; 
$noresave{$key} = "$nosave";

$key = q/newAndOldF0/;
$ref_files{$key} = "$dir".q|node9.html|; 
$noresave{$key} = "$nosave";

$key = q/sg0/;
$ref_files{$key} = "$dir".q|node19.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_matsui2003euros2/;
$ref_files{$key} = "$dir".q|node28.html|; 
$noresave{$key} = "$nosave";

$key = q/sg700/;
$ref_files{$key} = "$dir".q|node24.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_kawahara99spcom/;
$ref_files{$key} = "$dir".q|node28.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_kawahara2005interspeech/;
$ref_files{$key} = "$dir".q|node28.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_kawahara2003icassp/;
$ref_files{$key} = "$dir".q|node28.html|; 
$noresave{$key} = "$nosave";

$key = q/wv7/;
$ref_files{$key} = "$dir".q|node25.html|; 
$noresave{$key} = "$nosave";

$key = q/STRsgramforaiueo/;
$ref_files{$key} = "$dir".q|node31.html|; 
$noresave{$key} = "$nosave";

$key = q/wv6/;
$ref_files{$key} = "$dir".q|node22.html|; 
$noresave{$key} = "$nosave";

1;

